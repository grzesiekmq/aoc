function day9(txt) {
  const gridTxt = `......
......
......
......
H.....`;

  const s = [4, 0];
  let T = [4, 0];
  const H = [4, 0];
  const arr = txt.split("\n");
  const grid = gridTxt.split("\n").map((el) => [...el]);

  const visited = [s];

  const Hpositions = [];

  function putChar(y, x, ch) {
    grid[y][x] = ch;
  }

  function removeChar(y, x) {
    grid[y][x] = ".";
  }

  function goRight(amount) {
    for (let i = 0; x < amount; i++) {
      x++;
      console.log(i + 1 + "R --------------");
      xT++;
      console.log("H pos", y, x);
      console.log("T pos ", yT, xT);

      grid[y][x] = "H";
      grid[yT][xT] = "T";

      Hpositions.push([y, x]);

      visited.push([yT, xT]);
    }
  }

  function followHead(yTemp, xTemp) {
    yT = yTemp;
    xT = xTemp;
  }

  function goLeft(amount) {
    for (let i = 0; i < amount; i++) {
      x--;
      console.log(i + 1 + "L --------------");
      //   xT--;

      const HTemp = [y, x];
      let [yTemp, xTemp] = HTemp;

      if (Math.abs(x - xT) > 1 || Math.abs(y - yT) > 1) {
        followHead(yTemp, xTemp);
      }

      console.log("H pos", y, x);
      console.log("T pos ", yT, xT);

      grid[y][x] = "H";
      grid[yT][xT] = "T";

      Hpositions.push([y, x]);

      visited.push([yT, xT]);
    }
  }

  function goDown(amount) {
    for (let i = 0; i < amount; i++) {
      const HTemp = [y, x];
      let [yTemp, xTemp] = HTemp;

      y++;
      console.log(i + 1 + "D --------------");
      //   yT++;

      if (Math.abs(x - xT) > 1 || Math.abs(y - yT) > 1) {
        followHead(yTemp, xTemp);
      }

      console.log("H pos", y, x);
      console.log("T pos ", yT, xT);

      grid[y][x] = "H";
      grid[yT][xT] = "T";

      Hpositions.push([y, x]);

      visited.push([yT, xT]);
    }
  }

  function goUp(amount) {
    for (let i = 0; i < amount; i++) {
      const HTemp = [y, x];
      let [yTemp, xTemp] = HTemp;

      y--;

      console.log(i + 1 + " U --------------");

      if (Math.abs(x - xT) > 1 || Math.abs(y - yT) > 1) {
        followHead(yTemp, xTemp);
      }

      console.log("H pos", y, x);
      console.log("T pos ", yT, xT);

      grid[y][x] = "H";
      grid[yT][xT] = "T";

      Hpositions.push([y, x]);

      visited.push([yT, xT]);
    }
  }

  function moveBoth(dir, amount) {
    switch (dir) {
      case "R":
        goRight(amount);
        break;
      case "L":
        goLeft(amount);
        break;
      case "D":
        goDown(amount);
        break;
      case "U":
        goUp(amount);
        break;
      default:
        console.log("wrong direction");
    }
  }

  let [y, x] = H;
  let [yT, xT] = T;
  console.log("H pos", H);
  console.log("T pos ", T);

  //  move H
  x++;
  console.log("H pos", H);
  console.log("T pos ", T);

  //   console.log("------- R 4 -------");
  //   moveBoth("R", 4);
  //   console.log("------- U 4 -------");
  //   moveBoth("U", 4);
  //   console.log("------- L 3 -------");

  //   moveBoth("L", 3);
  //   moveBoth('D', 1)
  const arrTransformed = arr.map((el) => el.split(" "));
  for (const el of arrTransformed) {
    const [dir, amount] = el;
    moveBoth(dir, amount);
  }

  console.log(grid.join("\n"));

  const filteredNegatives = visited.filter((subarr) =>
    subarr.every((el) => el >= 0)
  );

  console.log("filtered negatives", filteredNegatives);

  const noDuplicates = [
    ...new Set(filteredNegatives.map((subarr) => JSON.stringify(subarr))),
  ].map((el) => JSON.parse(el));

  const testGridTxt = `......
......
......
......
......`;

  const testGrid = testGridTxt.split("\n").map((el) => [...el]);

  function fillGridWithHashes() {
    for (let yy = 0; yy < testGrid.length; yy++) {
      for (let xx = 0; xx < testGrid[yy].length; xx++) {
        for (const pos of noDuplicates) {
          const [posY, posX] = pos;
          testGrid[posY][posX] = "#";
        }
      }
    }
  }

  fillGridWithHashes();
  const txtGrid = [...testGrid.join("\n")].filter((el) => el !== ",");

  const ctx = document.querySelector("canvas").getContext("2d");
  ctx.fillStyle = "red";
  function putRect(x, y) {
    ctx.fillStyle = "red";
    ctx.fillRect(x, y, 10, 10);
  }

  //map coords

  //              0       1      2  3  4  5
  //                  210, 20   220

  // 0,0         200,   20
  //1,0                 40
  //2,0                 60
  //3,0    ->           80
  // 4,0 ->      200, 100

  const offsetX = 210;
  const offsetY = 20;

  const positions = [];
  function gridToCanvasCoords() {
    for (const pos of noDuplicates) {
      const [x, y] = pos;
      positions.push([x * 10 + offsetX, y * 10 + offsetY]);
    }
  }

  gridToCanvasCoords();

  console.log(positions);

  let i = 0;
  function typewrite() {
    if (i >= positions.length) {
      return;
    }
    const pos = positions[i];
      const [x, y] = pos;

    // document.querySelector("#demo").innerText = pos
    i++;
      putRect(y, x);

    setTimeout(typewrite, 1000);
  }

  typewrite();

  console.log(
    [...txtGrid]
      .map((el, i) => [el, i])
      .filter((subarr) => subarr.some((el) => el === "#"))
  );
  return noDuplicates;
}

console.log(
  day9(`R 4
U 4
L 3
D 1
R 4
D 1
L 5
R 2`)
);
