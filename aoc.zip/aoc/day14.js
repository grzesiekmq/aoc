function day14(txt) {
  const arr = txt.split("\n");
  const points = arr
    .map((el) => el.split("->"))
    .map((line) =>
      line
        .map((point) => point.trim())
        .map((point) => point.split(",").map((el) => +el))
    )
    .flat();

  const ctx = document.querySelector("canvas").getContext("2d");

  function drawLineCustom(
    p1,
    p2,
    color,
    y1Offset = 0,
    y2Offset = 0,
    x1Offset = 0,
    x2Offset = 0,
    lineWidth = 50
  ) {
    const [x1, y1] = p1;
    const [x2, y2] = p2;

    ctx.beginPath();
    ctx.moveTo(x1 + x1Offset, y1 + y1Offset);
    ctx.lineTo(x2 + x2Offset, y2 + y2Offset);
    ctx.strokeStyle = color;
    ctx.lineWidth = lineWidth;
    ctx.stroke();
  }

  function putRect(point, size, color, yOffset = 0, xOffset = 0) {
    ctx.fillStyle = color;
    const [x, y] = point;
    const [w, h] = size;
    ctx.fillRect(x + xOffset, y + yOffset, w, h);
  }

  for (let i = 0; i < points.length; i++) {
    //   putRect(points[i], 50,50, 'brown')
  }

  const p0 = points[0];
  const p1 = points[1];

  const p2 = points[2];
  const p3 = points[3];
  const p4 = points[4];
  const p5 = points[5];

  const size = [50, 50];

  // putRect(p0, size, 'brown', 150)

  // putRect(p1, size, 'brown', 200)

  //0 1  1 2  2 3  3 4  4 5

  const firstPathL1 = [p0, p1];

  const firstPathL2 = [p1, p2];

  const secondPathL1 = [p2, p3];
  const secondPathL2 = [p3, p4];
  const secondPathL3 = [p4, p5];

  let yoffset = 150;
  let xoffset = -50;

  function rectRegion(
    line,
    amount,
    yOffset = 0,
    xOffset = 0,
    yvalue = 0,
    xvalue = 0,
    dbgColor = false
  ) {
    for (let i = 0; i < amount; i++) {
      for (const p of line) {
        if (dbgColor) {
          const color = "green";
          putRect(p, size, color, yOffset, xOffset);
        } else {
          putRect(p, size, "brown", yOffset, xOffset);
        }
      }

      yOffset += yvalue;
      xOffset += xvalue;
    }
  }

  function firstPath() {
    rectRegion(firstPathL1, 3, yoffset, 0, 100, 0, true);
    rectRegion(firstPathL2, 2, 250, xoffset, 0, -50, true);
  }

  // rectRegion(firstPathL1, 2, 50)

  for (const p of firstPathL1) {
    // putRect(p, size);

    console.log(p);
  }

  //test
  // putRect(p1, size, "black", 50, 0);

  //   firstPath();

  function secondPath() {
    rectRegion(secondPathL1, 2, 200, 200, 0, 0);
    rectRegion(secondPathL2, 6, 200, 150, 100);
    rectRegion(secondPathL3, 8);
  }

  //   secondPath();

  function sandSrc() {
    putRect([500, 0], size, "yellow", 0, 50);
  }

  sandSrc();

  ctx.strokeRect(250, 5, 500, 500);

  function firstPathLineVer() {
    drawLineCustom(p0, p1, "brown", 300, 150, 25, 25);

    drawLineCustom(p1, p2, "brown", 275, 275, -100);
  }

  function secondPathLineVer() {
    drawLineCustom(p2, p3, "brown", 200, 250, 150, 250);

    drawLineCustom(p3, p4, "brown", 200, 500, 175, 175);

    drawLineCustom(p4, p5, "brown", 475, 475, -250, 200);
  }

  firstPathLineVer();
  secondPathLineVer();

  const iterations = 5;
  const positions = new Array(iterations).fill(false);

  console.log(positions);

  //draft

  let x = 500;
  let y = 400;
  function fillWithSand() {
    x -= 50;

    putRect([x, 400], size, "yellow", 0, 50);
  }



  

  function nextLogic(rect, xPos, yPos, conditionVal) {
    if (next) {
      let [xr, yr] = rect;
      ctx.clearRect(xr, yr, 50, 50);
      rect[1] += 1;

      putRect(rect, size, "yellow");
      if (rect[1] === conditionVal) {
        ctx.clearRect(xr, yr, 50, 50);
        rect[0] = xPos;
        rect[1] = yPos;
      }

      next = true;
    }

  }

  let ySand = 0;
  let xSand = 550;
  const rectangle1 = [xSand, ySand];
  const rectangle2 = [550, 0];
  const rectangle3 = [550, 0];
  const rectangle4 = [550, 0];
  const rectangle5 = [550, 0];

  let notYetRock = true;
  
  let next = false;
  function render() {
    document.querySelector("#demo").innerText = "x:" + xSand + " y:" + ySand;
    // for (const pos of positions) {
      
      requestAnimationFrame(render);
      ctx.clearRect(xSand, ySand, 50, 50);
    }
    


    if (xSand === 250) {
      xSand = 250;
    }
    if (ySand === 400) {
      notYetRock = false;
      putRect([xSand, ySand], size, "yellow");
      // positions[pos] = true
      // xSand -= 1

      next = true;
    }
    nextLogic(rectangle2, 400, 500, 350);
    notYetRock = true
    if (notYetRock) {
      ySand += 1;
      putRect([xSand, ySand], size, "yellow");

    } else if (!notYetRock) {
      rectangle2[0] = 500;
      rectangle2[1] = 400;
      // nextLogic(rectangle3, 450, 400, 300);

      rectangle3[0] = 450;
      rectangle3[1] = 400;
      notYetRock = false
      next = true;
    }
    // nextLogic(rectangle4, 400, 400, 250);

    // nextLogic(rectangle5, 300, 300, 250);

    // if(positions[pos]){
    // putRect([xSand,ySand],size, 'yellow');
    // }

    // }
 


 //   render();

 
 /*
 putRect([550, 400], size)
 arrBlocked.push(true)
 if(arrBlocked[0]){
   
  putRect([500, 400], size)
  arrBlocked.push(true)
}
if(arrBlocked[1]){
  
  putRect([450, 400], size)
  arrBlocked.push(true)
  
}
putRect([400, 400], size)
*/
const sandBlocked = []


let sandsrcx = 550
let sandsrcy = 0
function generate(iterations){
 let x = sandsrcx
 let y = sandsrcy
  for (let i = 0; i < iterations; i++) {
y += 50
    let rx = x
    let ry = 400
    putRect([rx, y], size)
    sandBlocked.push([rx, y])
    if(sandBlocked[i]){
      putRect([x -= 50, 450 - 50],size)
    }
    else {
      putRect([x += 50, 400],size)
     }

  }
}

generate(2)

document.querySelector('#demo').innerText = sandBlocked



  function gridHelper() {
    const p1Air = [250, 5];
    const p2Air = [800, 5];

    const p3Air = [250, 500];
    const p4Air = [250, 5];
    for (let i = 0; i < 9; i++) {
      drawLineCustom(p1Air, p2Air, "blue", 50 + i * 50, 50 + i * 50, 0, 0, 1);
      drawLineCustom(p3Air, p4Air, "blue", 0, 0, 50 + i * 50, 50 + i * 50, 1);
    }
  }

  gridHelper();
}

console.log(
  day14(`498,4 -> 498,6 -> 496,6
    503,4 -> 502,4 -> 502,9 -> 494,9`)
);
