function day12(txt) {

    const arr =  txt.split('\n').map(el => [...el]) 

    console.log(arr.flat());

    function bfs(S, vertices, grid) {
    const path = [];
    const visited = Array(vertices).fill(0)

    visited['S']
     
    if (visited[i] === 0) {
        const q = [];
        visited[i] = 1
         q.push(i);
        
        while (q.length > 0) {
            let S = q[0]
            q.shift();
            for (const row of grid) {
                for (const el of row) {
                    
                    if (visited[el] === 0) {
                        visited[el] = 1
                        q.push(el);
                        path.push(el);
                    }
                }
            }
        }
    }


    return path;
  }
  
  console.log('path',
    bfs(arr.flat().length, arr
        )
  );
}

console.log(
  day12(`Sabqponm
abcryxxl
accszExk
acctuvwj
abdefghi`)
);
