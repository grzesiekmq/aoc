function calc(item, value, opType) {
  let checkOpAdd = false;
  let checkOpMul = false;
  let checkOpSq = false;

  if (opType === "add") {
    checkOpAdd = true;
  } else if (opType === "mul") {
    checkOpMul = true;
  } else if (opType === "sq") {
    checkOpSq = true;
  }

  if (checkOpAdd) {
    return item + value;
  } else if (checkOpMul) {
    return item * value;
  } else if(checkOpSq) {
    return item * item;
  }
}

function isDivisible(worryLvl, divisor) {
  return worryLvl % divisor === 0;
}

function day11(txt) {
  const arr = txt.split("\n").filter((el) => el !== "");

  const monkeysInfo = [];

  for (let i = 0; i < arr.length; i += 6) {
    monkeysInfo.push(arr.slice(i, i + 6));
  }

  const monkeys = [];

  const demo = document.querySelector("#demo");

  for (const info of monkeysInfo) {
    const [name, startingItems, operation, divisibility, ifTrue, ifFalse] =
      info;

    const items = startingItems
      .slice(16)
      .split(",")
      .map((el) => el.trim())
      .map((el) => +el);

    const checkOpMul = operation.includes("old *");
    const checkOpAdd = operation.includes("old +");

    const checkOpSq = operation.includes("old * old");

    let opType = "";

    const value = +operation.split(" ").at(-1);

    const divisor = +divisibility.slice(19);

    const monkeyT = +ifTrue.at(-1);

    const monkeyF = +ifFalse.at(-1);

    if (checkOpAdd) {
      opType = "add";
    }
    else if (isNaN(value) && checkOpSq) {
      opType = "sq";
    }
    else if (checkOpMul) {
     opType = "mul";
   }
  
  else {
      console.log('noop');
    }


    
    monkeys.push({name,
      items,
      value,
      opType,

      divisor,
      monkeyT,
      monkeyF,
    });
  }

  function round(monkeys){
    
    for (const monkey of monkeys) {
      const {name, items, value, opType, divisor, monkeyT, monkeyF } = monkey;
   
   
   
      let opTxt = "";
    if (opType === "mul") {
      opTxt = "is mul by ";
    } else if (opType === "add") {
      opTxt = "increases by ";
    } else if (opType === 'sq') {
      opTxt = "mul by itself";
    }
    
    demo.innerText += name + "\n";
    
     

      console.log(items.length);
     
      for (const item of items) {
        
        const itemToPass = items.shift()
        
        
        const lvlAfterInspection = calc(itemToPass, value, opType);
        const currentWorryLvl = Math.round(lvlAfterInspection / 3);
        
        const whichMonkey = isDivisible(currentWorryLvl, divisor)
        ? monkeyT
        : monkeyF;
        
        // console.log(monkey);
        
        monkeys[whichMonkey].items.push(currentWorryLvl)
        
        
        
        demo.innerText +=
        "Monkey inspects item with worry lvl of: " +
        itemToPass +
        "\n" +
        "Worry lvl " +
        opTxt +
        value +
        " to " +
        lvlAfterInspection +
        "\n" +
        "Monkey gets bored with item. Worry lvl is divided by 3 to " +
        currentWorryLvl +
        "\n" +
        "Current worry lvl is not divisible by " +
        divisor +
        "\n" +
        "Item with worry lvl " +
        currentWorryLvl +
        " is thrown to " +
        whichMonkey +
        "\n" +
        "-----------------------------------" +
        "\n";
        
      }
        
        
        console.log('after round', monkey.name, monkey.items)
      }
    }
    
    // for (let i = 0; i < 1; i++) {
  demo.innerText += '---------------------------------------' + '\n'
  // demo.innerText += '----------------------- round ' + i + '\n'
  round(monkeys)
  // console.log('round ' + i)
// }

    return;
  }
  
  console.log(
  day11(`Monkey 0:
Starting items: 79, 98
Operation: new = old * 19
Test: divisible by 23
  If true: throw to monkey 2
  If false: throw to monkey 3

Monkey 1:
Starting items: 54, 65, 75, 74
Operation: new = old + 6
Test: divisible by 19
  If true: throw to monkey 2
  If false: throw to monkey 0

Monkey 2:
Starting items: 79, 60, 97
Operation: new = old * old
Test: divisible by 13
  If true: throw to monkey 1
  If false: throw to monkey 3

Monkey 3:
Starting items: 74
Operation: new = old + 3
Test: divisible by 17
  If true: throw to monkey 0
  If false: throw to monkey 1`)
);
