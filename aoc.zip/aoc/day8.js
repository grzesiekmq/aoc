function day8(txt) {
  const arr = txt.split("\n").map((el) => el.trim());
  const store = [];

  const topLeft = arr[1][1];
  const topMiddle = arr[1][2];
  const topRight = arr[1][3];

  const middleLeft = arr[2][1];
  const middle = arr[2][2];
  const middleRight = arr[2][3];

  const bottomLeft = arr[3][1];
  const bottomMiddle = arr[3][2];
  const bottomRight = arr[3][3];
  function makeSubgrid() {
    const topRow = [];
    const middleRow = [];
    const bottomRow = [];

    topRow.push(topLeft, topMiddle, topRight);

    middleRow.push(middleLeft, middle, middleRight);

    bottomRow.push(bottomLeft, bottomMiddle, bottomRight);

    store.push(topRow, middleRow, bottomRow);
  }

  makeSubgrid();
  console.log("store", store);

  /* for (let x = 0; x < store.length; x++) {
    const row = store[x];

    // console.log("row", row);
    for (let y = 0; y < row.length; y++) {
      const el = row[y];
    //   console.log("el", el);
    }
  } */
  const positions = [
    [1, 1],
    [1, 2],
    [1, 3],

    [2, 1],
    [2, 2],
    [2, 3],

    [3, 1],
    [3, 2],
    [3, 3],
  ];
  function walk(x, y, dir) {
    switch (dir) {
      case "left":
        x--;
        break;
      case "right":
        x++;
        break;

      case "down":
        y++;
        break;

      case "up":
        y--;
        break;
      default:
        console.log("wrong direction");
    }
    return [x, y];
  }

  function testTemp() {
    const posL = walk(1, 1, "left");
    const [x, y] = posL;

    console.log("start", topLeft);
    console.log("pos after L", arr[x][y]);

    if (arr[x][y] < topLeft) {
      console.log("shorter tree on L");
    }

    const posR = walk(1, 1, "right");
    const [xR, yR] = posR;

    if (arr[xR][yR] < topLeft) {
      console.log("shorter tree on R");
    }

    const posD = walk(1, 1, "down");
    const [xD, yD] = posD;
    console.log("pos after D", arr[xD][yD]);

    while (arr[xD][yD] < topLeft) {
      console.log("shorter tree on D");
      walk(xD, yD, "down");
    }
    console.log("current pos", xD, yD, "el", arr[xD][yD]);

    const posU = walk(1, 1, "up");
    const [xU, yU] = posU;

    console.log("pos after U", arr[xU][yU]);

    if (arr[xU][yU] < topLeft) {
      console.log("shorter tree on U");
    }
  }

  const dirs = ["left", "right", "down", "up"];

  let countMoves = 0;
  const visibles = [];
  for (let i = 0; i < positions.length; i++) {
    const position = positions[i];

    const [xStart, yStart] = position;
    const visited = [];
    for (const dir of dirs) {
      console.log("------------------------------");
      console.log("start position", xStart, yStart);

      let posMoved = walk(xStart, yStart, dir);
      countMoves++;
      let [x, y] = posMoved;
      if (arr[x][y] < arr[xStart][yStart]) {
        posMoved =  walk(x,y, dir)
        countMoves++;

        // if ((x < 0 || y < 0) || (x > 5 || y > 5)) {
          console.log("shorter tree on " + dir);
      }

      visited.push(arr[x][y]);

      if (visited.every((el) => el < arr[xStart][yStart])) {
        console.log("every tree here is less in height than starting");

        visibles.push(arr[xStart][yStart]);

        // walk(x,y, dir)

      } else if (arr[x][y] >= arr[xStart][yStart]) {
        console.log("this tree is taller or equal in height");
        continue;
      }
      console.log("visited", visited);

      console.log(
        "move",
        countMoves,
        "current pos",
        x,
        y,
        "el",
        arr[x][y],
        "dir ",
        dir
      );

      visited.length = 0;
    }
  }

  console.log("moves ", countMoves);

  console.log("visible trees", visibles);

  return visibles.length;
}

console.log(
  day8(`30373
                25512
                65332
                33549
                35390`)
);
